/* i created an enum to represent the 4 possbile suits og a card */
public enum Suit {
    Clubs,
	Diamonds,
	Spades,
	Hearts,
}
